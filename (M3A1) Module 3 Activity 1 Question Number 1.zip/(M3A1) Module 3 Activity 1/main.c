#include <stdio.h>
#include <stdlib.h>

int main()
{
/*[1]Write a C program to check whether a given number is even or odd.*/


    int numToBeTestedIfEvenOrOdd;
//numToBeTestedIfEvenOrOdd is declared as an int/integer, it will hold a value that the user will provide.

    int numToBeTestedIfEvenOrOddHolder;
//numToBeTestedIfEvenOrOddHolder is declared as an int/integer,
// it will temporarily hold the value of numToBeTestedIfEvenOrOdd that the user provided to be used later.

    int moduloHolder;
//modoluHolder will hold the modulo of numToBeTestedIfEvenOrOdd to know if it has modulo or not.

    printf("Enter a value to be checked: ");
//the user will be prompted and asked to enter a value

    scanf("%d", &numToBeTestedIfEvenOrOdd);
//this will take what ever the user gives and store it to variable numToBeTestedIfEvenOrOdd.

    numToBeTestedIfEvenOrOddHolder = numToBeTestedIfEvenOrOdd;
// the value of numToBeTestedIfEvenOrOdd will now be stored to numToBeTestedIfEvenOrOddHolder for lated usage.

    moduloHolder = numToBeTestedIfEvenOrOdd % 2;
// the modulo of numToBeTestedIfEvenOrOdd will now be stored to numToBeTestedIfEvenOrOdd.

        //printf("%d", modoluHolder+);

    if(moduloHolder == 0){
        printf("the number you entered is %d and it is even", numToBeTestedIfEvenOrOddHolder);
// if moduloHolder's value is equal to zero, this means that numToBeTestedIfEvenOrOdd is divisible by 2.
//this also means that, it is an even number.
//and whatever printf contains will be prompted/tell to the user.
    }else{
        printf("the number you entered is %d and it is odd", numToBeTestedIfEvenOrOddHolder);
//else if moduloHolder's value is not equal to zero, this means that numToBeTestedIfEvenOrOdd is not divisible by 2.
//this also means that, it is an odd number.
//and whatever printf contains will be prompted/tell to the user.
    }


    return 0;
}
