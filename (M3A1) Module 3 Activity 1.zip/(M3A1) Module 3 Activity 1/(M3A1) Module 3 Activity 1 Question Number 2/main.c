#include <stdio.h>
#include <stdlib.h>

int main()
{
/*[2]Write a C program to check whether a number is positive, negative*/

    int numToBeTestedIfPositiveOrNegative;
//integer numToBeTestedIfPositiveOrNegative is declared.

    printf("Enter a number to be checked if it is a Positive or Negative : ");
//the program will prompt the user to enter a number.

    scanf("%d", &numToBeTestedIfPositiveOrNegative);
//this will scan/take what ever number, the user will enter and store it to variable numToBeTestedIfPositiveOrNegative.

    if(numToBeTestedIfPositiveOrNegative < 0){
        printf("you entered %d, and it is a Negative number", numToBeTestedIfPositiveOrNegative);
//this will test if numToBeTestedIfPositiveOrNegative's value is lesser than zero,
//if it is lesser than zero, it is a Negative number and whatever printf contains will be prompted to the user
    }else{
        printf("you entered %d, and it is a Positive number", numToBeTestedIfPositiveOrNegative);
//if numToBeTestedIfPositiveOrNegative's value is greater than zero,
//it is a Positive number and whatever printf contains will be prompted to the user
    }

    return 0;
}
