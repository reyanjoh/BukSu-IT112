#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main()
{
    printf("Enter a character to check weather is it a vowel or a consonant : ");
    char userInput;
    int lowercase_vowel, uppercase_vowel;
    scanf("%c", &userInput);

    lowercase_vowel = (userInput == 'a' || userInput == 'e' || userInput == 'i' || userInput == 'o' || userInput == 'u');

    uppercase_vowel = (userInput == 'A' || userInput == 'E' || userInput == 'I' || userInput == 'O' || userInput == 'U');

    if (lowercase_vowel || uppercase_vowel){
        printf("%c is a vowel.", userInput);
    }else if(isalpha(userInput)){
        printf("%c is a consonant.", userInput);
    }else{
        printf("sorry but... %c is a number.", userInput);
    }
}
