#include <stdio.h>
#include <stdlib.h>



int main()
{
    system("color a");

    printf("this program will check if the triangle is valid \n\naccording to the 3 angles inputted by the user \n\nusing the triangle inequality theorem.");

    int angleA, angleB, angleC;

    printf("\n\n Press any key to continue...");
    getch();
    system("cls");

    printf("\n\n Enter value for the first angle : ");
    scanf("%d", &angleA);
    system("cls");

    printf("\n\n Enter value for the second angle : ");
    scanf("%d", &angleB);
    system("cls");

    printf("\n\n Enter value for the third angle : ");
    scanf("%d", &angleC);
    system("cls");

    if( angleA+angleB>angleC || angleB+angleC>angleA || angleC+angleA>angleB){
        printf("\n\n\nyou entered a = %d, b = %d, and c = %d a valid triangle values!\n\n\n", angleA, angleB, angleC);
        getch();
        system("cls");
        printf(" as long as the user enters an integer number it will always be valid by default...\n\n\n ");
        getch();
    }
}





















