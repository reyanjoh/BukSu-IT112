#include <stdio.h>
#include <stdlib.h>

int main()
{
    int hour = 0;
    int min = 0;
    int sec;
    int temp = 0;

    printf("Enter time in seconds: ");
    scanf("%i", &sec);

    while(sec != 0){
        sec--;
        temp++;
        if(temp == 60){
            temp = 0;
            min++;
            //printf("%d", min);
            if(min == 60){
                min = 0;
                hour++;
                 //printf("%d", hour);
            }
        }

        //if(sec == 0){
          //  printf("time =  %d hours : %d minutes : %d seconds", hour, min, temp);
       // }
    }
    system("cls");
    //system("@cls||clear");
    printf("time =  %d hours : %d minutes : %d seconds", hour, min, temp);
    printf("\n");
    printf("\n");
    printf("\n");
    printf("\n");

}
