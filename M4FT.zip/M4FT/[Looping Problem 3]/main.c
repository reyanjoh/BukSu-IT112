#include <stdio.h>
#include <stdlib.h>

int main()
{
    system("color a");

/*---------------------------------------- Problem ----------------------------------------*/

    printf("\t\t\t  ----[Looping Problem 3]----\n\n");
    printf("Suppose you are given ten cent on day 1 and on day 2 you are given twice as\n");
    printf("much. If each day you are given twice as much money as on the previous day,\n");
    printf("then on day 15, how much money you will receive? Build a C program to find\n");
    printf("the solution. Print each total money a day.\n\n\n");

    system("pause");
    system("cls");
/*---------------------------------------- Code start ----------------------------------------*/
    int day, cent;
    cent = 10;
    day = 1;
    while(day <= 15){
        printf("day %d : %d cent \n", day,cent );
        cent = cent*2;
        day++;
    }

}
