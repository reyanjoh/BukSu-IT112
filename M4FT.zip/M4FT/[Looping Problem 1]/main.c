#include <stdio.h>
#include <stdlib.h>

int main(){

    printf("\t\t[Looping Problem 1] \n\nPrint out the squares of the first 10 integers.\n\n");
    printf("I use Geometric Sequence to solve this problem, \nso that the user only inputs 2 numbers\n\n\n");
    printf("Please enter reasonable numbers\n\n\n");
    system ("pause");
    system ("cls");

    int firstTerm, secondTerm, commonRatio, valuesSecondIndex;
    int values[10], squredValues[10];

    secondTerm = 0;
    valuesSecondIndex = 2;

    /*this asks the user to enter the value of the first term*/
    printf("\nEnter the first term: ");
    scanf("%d", &firstTerm);
    system ("cls");


    /*prompts the user to enter a greater value for the second term*/
        printf("Enter the second term: ");
        scanf("%d", &secondTerm);
        system ("cls");
    while(firstTerm > secondTerm || commonRatio == 1){
        printf("Please enter a value that is 2 times greater than %d or more: ", firstTerm);
        scanf("%d", &secondTerm);
    }
    commonRatio = secondTerm/firstTerm;
    system ("cls");

    /*this sets the values of the first and second terms*/
    values[1] = firstTerm;
    values[2] = secondTerm;

    //printf("%d %d", firstTerm, secondTerm);


    /*this inserts the value of the 3rd terms value to up to the 10th term*/
    for(int i = 3; i != 11; i++){
        values[i] =  values[valuesSecondIndex] * commonRatio;
        valuesSecondIndex++;
    }

    /*this code is to test the result of the Geometric Sequence
    remove the single line comments to test*/

    //for(int k = 1; k !=11; k++){
    //    printf("%d \n", values[k]);
    //}


    /*this calculate and ptints the squares of the first 10 integers.*/
    int k = 1;
    for(int j = 1; j !=11; j++){
        squredValues[j] = values[k]*values[k];
        printf("term No.%d. %d \n", k, squredValues[j]);
        k++;

    }


}

































