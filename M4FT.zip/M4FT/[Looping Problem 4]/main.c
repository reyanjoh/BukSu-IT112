#include <stdio.h>
#include <stdlib.h>

int main(){



    printf("\t\t\t[Looping Problem 4]");
    printf("\n\n\nWrite a program in C make a pattern like a pyramid with numbers.");
    printf("\nThe user inputs how many rows to be pattern.\n\n");
    printf("");

    system("pause");

    int space, rows, k, t, i, j;
    t = 1;

   printf("Input number of rows : ");
   scanf("%d", &rows);

   space = rows + 4 - 1;

   for( i = 1; i <= rows ; i++ ){
         for( k = space; k >= 1; k-- ){
              printf(" ");
            }
	   for( j = 1; j <= i; j++)
	   printf("%d ", t++);
	printf("\n");
    space--;
   }


}
