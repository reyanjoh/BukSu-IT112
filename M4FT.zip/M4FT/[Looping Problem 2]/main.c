#include <stdio.h>
#include <stdlib.h>

int main()
{

/*---------------------------------------- Problem ----------------------------------------*/
    system("color a");

    printf("\t\t\t  ----[Looping Problem 2]----\n\n");

    printf("The user need to input a number range (e.g 10,150,777)\n");
    printf("The program must print from 1 to number range but skip all the numbers that are divisible by 3\n");
    printf("Add all printed numbers and print it.\n\n\n");

    system("pause");
    system("cls");

/*---------------------------------------- Code start ----------------------------------------*/

    int value, newValue, maxValue, divisibleChecker;
    newValue = 1;
    value = 1;

    printf("Enter Max value of the number range: ");
    scanf("%d", &maxValue);

    do{
        divisibleChecker = value % 3;


        if( divisibleChecker != 0 ){

            printf("%d\t ", value);

            if( divisibleChecker != 0 ){

                newValue = newValue + value;
            }

            value++;
        }else{
            value++;
        }

    }while(value <= maxValue);
    printf("\n\n%d in total divisible by 3 are excluded\n\n\n", newValue);
}
