#include <stdio.h>
#include <stdlib.h>

int main()
{
    int hour = 0;
    int min = 0;
    int initialSeconds;
    int secPlaceolder;
    int secFinalOutput = 0;

    printf("Enter time in seconds: ");
    scanf("%i", &initialSeconds);

    secPlaceolder = initialSeconds;


    while(initialSeconds != 0){
        initialSeconds--;
        secFinalOutput++;
        if(secFinalOutput == 60){
            secFinalOutput = 0;
            min++;
            //printf("%d", min);
            if(min == 60){
                min = 0;
                hour++;
                 //printf("%d", hour);
            }
        }

        //if(initialSeconds == 0){
          //  printf("time =  %d hours : %d minutes : %d seconds", hour, min, secFinalOutput);
       // }
    }
    system("cls");
    //system("@cls||clear");
    printf("%d seconds = %d hours : %d minutes : %d seconds", secPlaceolder, hour, min, secFinalOutput);
    printf("\n");
    printf("\n");
    printf("\n");
    printf("\n");

}
